from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS, HOST, PORT, DB, COL):
         # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        USER = 'aacuser'
        PASS = 'GonSNHU1234'  
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 34053
        DB = 'AAC'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """ Inserts a document into the MongoDB collection """
        if data is not None:
            result = self.database.animals.insert_one(data)
            return result.inserted_id
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, readData):
        """ readData for documents from the MongoDB collection """
        if readData:
            data = self.database.animals.find(readData, {"_id": False})
        else:
            data = self.database.animals.find({}, {"_id": False})
            return data
        
        return list(data)
    
    def update(self, query, update_data, multiple=False):
        """ Updates document(s) in the MongoDB collection """
        if query and update_data:
            if multiple:
                result = self.database.animals.update_many(query, {"$set": update_data})
            else:
                result = self.database.animals.update_one(query, {"$set": update_data})
            return result.modified_count
        else:
            raise Exception("Query and update data parameters cannot be empty")
            
    def delete(self, query):
        """ Deletes document(s) from the MongoDB collection """
        if query:
            result = self.database.animals.delete_many(query)
            return result.deleted_count
        else:
            raise Exception("Query parameter cannot be empty")
            
    def get_rescue_types(self):
        """ Retrieve unique rescue types from the collection """
        return self.collection.distinct('rescue_type')

    def get_preferred_breeds(self):
        """ Retrieve unique preferred dog breeds from the collection """
        return self.collection.distinct('preferred_breed')